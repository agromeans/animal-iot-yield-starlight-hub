from configparser import ConfigParser
from lib.logger_opt import *
import os

def write_share_config_last_capture_time(config, last_capture_time):
    config.read(share_config_file,encoding='UTF-8')
    config['param']['yield_last_capture_time'] = last_capture_time
    with open(share_config_file, 'w') as config_file:
        config.write(config_file)
        
def write_share_config_last_save_image_time(config, last_save_image_time):
    config.read(share_config_file,encoding='UTF-8')
    config['param']['yield_last_save_image_time'] = last_save_image_time
    with open(share_config_file, 'w') as config_file:
        config.write(config_file)
        
def init_share_config():
    init_time = '2000-01-01-00-00-00'
    
    share_config = ConfigParser()
    if not os.path.isfile(share_config_file):
        share_config['param'] = {
            'yield_last_capture_time': init_time,
            'yield_last_save_image_time': init_time
        }
    else:
        share_config.read(share_config_file)
        
        if not share_config.has_section('param'):
            share_config.add_section('param')
            
        if not share_config.has_option('param', 'yield_last_capture_time'):
            share_config.set('param', 'yield_last_capture_time', init_time)
            
        if not share_config.has_option('param', 'yield_last_save_image_time'):
            share_config.set('param', 'yield_last_save_image_time', init_time)
            
    with open(share_config_file, 'w') as config_file:
        share_config.write(config_file)
        
    return share_config 
    
config_file = './config.ini'
share_config_file = './share/config.ini'

config = ConfigParser()
config.read(config_file)

share_config = init_share_config()

version = ''

api_upload_record = ''
api_ai_predict = ''
api_dualcam_capture_rec_and_pc = ''

path_save_ai_dir = ''
path_save_raw_dir = ''
path_save_depth_dir = ''
path_save_heatmap_dir = ''
path_save_raw_left_dir = ''
path_save_raw_right_dir = ''

args_default_yolo_conf_thresh = None 
args_default_yolo_nms_thresh = None 
args_default_yolo_input_size = None 

### Bird ###
path_bird_weight_model = ''

# args_bird_yolo_conf_thresh = None 
# args_bird_yolo_nms_thresh = None 
# args_bird_yolo_input_size = None 

args_bird_camera_args = {'camera_args':{'camera_type':'dual','resolution_per_cam':(1920,1080)}}

param_pixel_value_min_limit = None
param_bbox_area_min_limit = 0
param_bird_binary_thr = 15
param_bird_num_thr = 5
param_capture_interval = '' 
param_save_image_interval = ''
param_last_capture_time = ''
param_last_save_image_time = ''

def update_last_capture_time_and_write_to_file(new_capture_time):
    global param_last_capture_time, share_config
    try:
        param_last_capture_time = new_capture_time 
        write_share_config_last_capture_time(share_config, new_capture_time)
    except Exception as e:
        logger.error(str(e))
        
def update_last_save_image_time_and_write_to_file(new_save_image_time):
    global param_last_save_image_time, share_config
    try:
        param_last_save_image_time = new_save_image_time
        write_share_config_last_save_image_time(share_config, new_save_image_time)
    except Exception as e:
        logger.error(str(e))
        
def get_version():
    return version
    
def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')
        
    if not config.has_section('path'):
        config.add_section('path')
        
    if not config.has_section('api'):
        config.add_section('api')
        
    if not config.has_section('args'):
        config.add_section('args')
        
    if not config.has_section('param'):
        config.add_section('param')
        
    config.write(open(config_file, 'w'))
    
def get_config():
    global version, path_save_ai_dir, path_save_raw_dir, path_save_depth_dir, path_save_heatmap_dir, path_save_raw_left_dir, path_save_raw_right_dir, path_bird_weight_model, api_upload_record, api_dualcam_capture_rec_and_pc, api_ai_predict, args_default_yolo_conf_thresh,  args_default_yolo_nms_thresh, args_default_yolo_input_size, param_pixel_value_min_limit, param_bbox_area_min_limit, param_capture_interval, param_save_image_interval ,param_last_capture_time, param_last_save_image_time
    
    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''
        
    try:
        path_save_ai_dir = config.get('path', 'save_ai_dir')
    except Exception as e:
        logger.warning(e)
        path_save_ai_dir = ''
        
    try:
        path_save_raw_dir = config.get('path', 'save_raw_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_dir = ''
        
    try:
        path_save_depth_dir = config.get('path', 'save_depth_dir')
    except Exception as e:
        logger.warning(e)
        path_save_depth_dir = ''
        
    try:
        path_save_heatmap_dir = config.get('path', 'save_heatmap_dir')
    except Exception as e:
        logger.warning(e)
        path_save_heatmap_dir = ''
        
    try:
        path_save_raw_left_dir = config.get('path', 'save_raw_left_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_left_dir = ''
        
    try:
        path_save_raw_right_dir = config.get('path', 'save_raw_right_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_right_dir = ''
        
    try:
        path_bird_weight_model = config.get('path', 'bird_weight_model')
    except Exception as e:
        logger.warning(e)
        path_bird_weight_model = ''
        
    try:
        api_upload_record = config.get('api', 'upload_record')
    except Exception as e:
        logger.warning(e)
        api_upload_record = ''
        
    try:
        api_dualcam_capture_rec_and_pc = config.get('api', 'dualcam_capture_rec_and_pc')
    except Exception as e:
        logger.warning(e)
        api_dualcam_capture_rec_and_pc = ''
        
    try:
        api_ai_predict = config.get('api', 'ai_predict')
    except Exception as e:
        logger.warning(e)
        api_ai_predict = ''
        
    try:
        args_default_yolo_conf_thresh = config.get('args', 'default_yolo_conf_thresh')
    except Exception as e:
        logger.warning(e)
        args_default_yolo_conf_thresh = None 
        
    try:
        args_default_yolo_nms_thresh = config.get('args', 'default_yolo_nms_thresh')
    except Exception as e:
        logger.warning(e)
        args_default_yolo_nms_thresh = None 
        
    try:
        args_default_yolo_input_size = config.get('args', 'default_yolo_input_size')
    except Exception as e:
        logger.warning(e)
        args_default_yolo_input_size = None 
        
    # try:
        # args_bird_yolo_conf_thresh = config.get('args', 'bird_yolo_conf_thresh')
    # except Exception as e:
        # logger.warning(e)
        # args_bird_yolo_conf_thresh = None 
        
    # try:
        # args_bird_yolo_nms_thresh = config.get('args', 'bird_yolo_nms_thresh')
    # except Exception as e:
        # logger.warning(e)
        # args_bird_yolo_nms_thresh = None 
        
    # try:
        # args_bird_yolo_input_size = config.get('args', 'bird_yolo_input_size')
    # except Exception as e:
        # logger.warning(e)
        # args_bird_yolo_input_size = None 
        
    try:
        param_pixel_value_min_limit = int(config.get('param', 'pixel_value_min_limit'))
    except Exception as e:
        logger.warning(e)
        param_pixel_value_min_limit = 0 
        
    try:
        param_bbox_area_min_limit = float(config.get('param', 'bbox_area_min_limit'))
    except Exception as e:
        logger.warning(e)
        param_bbox_area_min_limit = 0 
        
    try:
        param_capture_interval = int(config.get('param', 'capture_interval'))
    except Exception as e:
        logger.warning(e)
        param_capture_interval = '' 
        
    try:
        param_last_capture_time = share_config.get('param', 'yield_last_capture_time')
    except Exception as e:
        logger.warning(e)
        param_last_capture_time = '' 
        
    try:
        param_save_image_interval = int(config.get('param', 'save_image_interval'))
    except Exception as e:
        logger.warning(e)
        param_save_image_interval = '' 
        
    try:
        param_last_save_image_time = share_config.get('param', 'yield_last_save_image_time')
    except Exception as e:
        logger.warning(e)
        param_last_save_image_time = '' 
        
def reload_config():
    check_config_section()
    get_config()
    