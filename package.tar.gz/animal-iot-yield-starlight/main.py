# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify
import requests
import config
import argparse
import lib.opt as opt
import lib.utils as utils
from lib.logger_opt import logger
from lib.exception_opt import ExceptionCommon

app = Flask(__name__)
requests.packages.urllib3.disable_warnings()

@app.before_request
def before_request():
    logger.info("'{path}' start serving remote ip: {ip}".format(path=request.path, ip=request.remote_addr))

@app.route("/capture/weight")
def capture():
    now_time_str = utils.get_UTC_time_str()
    last_capture_time_str = config.param_last_capture_time 
    
    if utils.X_minus_1_min_later(now_time_str, last_capture_time_str, config.param_capture_interval):
        record = opt.capture_weight()
        config.update_last_capture_time_and_write_to_file(now_time_str)
        utils.http_post_request_json(config.api_upload_record, record)
    else:
        logger.info(f'Skip capture. Time interval <= {config.param_capture_interval} minutes.')
        
    respond = dict(status_code=200, message='')
    return jsonify(respond), 200

@app.route("/version")
def get_version():
    return config.version

@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message="404 Not Found")
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message="500 Error")
    return jsonify(response), 500

if __name__ == "__main__":
    config.reload_config()
    parse = argparse.ArgumentParser()
    parse.add_argument('-v', '--version', action='version', version=config.get_version(), help='Display version')
    parse.parse_args()

    logger.info('====The program is starting====')

    app.run(host='0.0.0.0', port=5085, threaded=False)